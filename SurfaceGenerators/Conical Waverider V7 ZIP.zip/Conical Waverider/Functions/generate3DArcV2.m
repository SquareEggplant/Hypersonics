function arcPoints = generate3DArcV2(P1, P2, C, N, num)
% generateArc3D - Generate arc points on a circle in 3D
% 
% Syntax: arcPoints = generateArc3D(P1, P2, C, N, num)
%
% Inputs:
%   P1  - Starting point [1x3]
%   P2  - Ending point   [1x3]
%   C   - Circle center  [1x3]
%   N   - Direction vector (defines arc orientation) [1x3]
%   num - Number of points along arc
%
% Output:
%   arcPoints - [3 x num] array of arc coordinates

    % Convert inputs to column vectors
    P1 = P1(:); P2 = P2(:); C = C(:); N = N(:);

    % Radius vectors from center
    v1 = P1 - C;
    v2 = P2 - C;

    % Normalize
    v1 = v1 / norm(v1);
    v2 = v2 / norm(v2);
    N  = N  / norm(N);

    % Define plane of circle using cross product
    planeNormal = cross(v1, v2);

    % If cross is near zero (P1 and P2 almost collinear w.r.t C), use N
    if norm(planeNormal) < 1e-12
        planeNormal = cross(v1, N);
    end
    planeNormal = planeNormal / norm(planeNormal);

    % Signed angle between v1 and v2, using planeNormal
    cosTheta = dot(v1, v2);
    cosTheta = min(max(cosTheta, -1), 1); % clamp
    theta = acos(cosTheta);

    % Ensure correct orientation using sign of scalar triple product
    if dot(planeNormal, cross(v1, v2)) < 0
        theta = -theta;
    end

    % Parameterize arc
    t = linspace(0, theta, num);

    % Rodrigues rotation formula
    arcPoints = zeros(num, 3);
    for i = 1:num
        arcPoints(i,:) = (rodriguesRot(v1, planeNormal, t(i)) * norm(P1-C))' + C';
    end
    arcPoints = arcPoints';
end


function vRot = rodriguesRot(v, k, theta)
% Rodrigues' rotation formula: rotate vector v about axis k by angle theta
    k = k / norm(k);
    vRot = v*cos(theta) + cross(k,v)*sin(theta) + k*dot(k,v)*(1-cos(theta));
end
