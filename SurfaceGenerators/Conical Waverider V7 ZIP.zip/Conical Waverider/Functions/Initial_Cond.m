% Eric Jo's Initial Condition Function
function [V_r0, V_theta0] = Initial_Cond(Shock_Angle, M1, gamma)

% Normal free-stream mach (M1)
Mn1 = M1*sind(Shock_Angle);

% Normal M2
Mn2 = sqrt( (1+0.5*(gamma-1)*Mn1^2) / (gamma*Mn1^2 - 0.5*(gamma-1)) );

% Theta-Beta-Mach Wedge Estimation
tangent_wedge_angle = 2*cotd(Shock_Angle)*(((M1^2)*(sind(Shock_Angle)^2) - 1)/ ...
    ((M1^2)*(gamma+cosd(2*Shock_Angle)) + 2));
wedge_angle = atand(tangent_wedge_angle);
% fprintf('Guess Cone/Wedge angle: %g deg\n\n', wedge_angle)

% M2 
M2 = Mn2/sind(Shock_Angle-wedge_angle);

% Non-dimensional initial velocities behind the shock
V2 = ((2/(gamma-1)) * (1/M2)^2 + 1)^(-0.5);
V_r0 = V2*cosd(Shock_Angle-wedge_angle);
V_theta0 = -V2*sind(Shock_Angle-wedge_angle);

% fprintf(['Vr initial: %g \n' ...
%     'Vtheta intial: %g \n\n'], V_r0, V_theta0)

end

