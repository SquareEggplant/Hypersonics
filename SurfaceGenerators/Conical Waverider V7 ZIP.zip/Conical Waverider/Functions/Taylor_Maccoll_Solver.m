% Eric Jo's Taylor Maccoll Solver Function
function [F] = Taylor_Maccoll_Solver(Velocity_Vector, gamma, Shock_Angle)

% Euler Explicit Solution of the Taylor Maccoll Equation
Vr = Velocity_Vector(1);
Vtheta = Velocity_Vector(2);

gamma_factor = (gamma-1)/2;

numer = gamma_factor * (1 - (Vr^2) - (Vtheta^2)) * ((2*Vr) + (Vtheta*cot(Shock_Angle))) - (Vr*(Vtheta^2));
denom = (Vtheta^2) - gamma_factor * (1 - (Vr^2) - (Vtheta^2));

F2 = numer/denom;

% 1st order system reduction
F = [Vtheta; F2];

end