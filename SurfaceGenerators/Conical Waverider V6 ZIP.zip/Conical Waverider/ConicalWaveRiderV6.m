%% CONICAL WAVERIDER GENERATOR 
% BY ERIC JO

% This script outputs stl's of conical waverider geometries.
% To begin generating waveriders, set the inputs you want and press run.

%% Inputs, Outputs, & Workspace Pathing
% Last updated 10.24.2025 / 07:12 AM (EST)
clear; clc; close all;
%===== FUNCTION PATH =====%
addpath(genpath(fullfile(pwd, 'Functions')))
%=========================%

%=====NEEDED FUNCTIONS=====%
% generate3DArcV2.m
% Initial_Cond.m
% Taylor_Maccoll_Solver.m
%==========================%

%=====INPUTS=====%
% Flow field variables
beta = 11;                  % Shock angle (deg)
beta_rad = deg2rad(beta);   % Shock angle (rad)
M1 = 8;                     % Freestream Mach number
gamma = 1.4;                % Specific heat ratio
h = -1e-5;                  % Integration step size (rad)

seed_num = 101;             % Number of LEP/TES Points
Shape_cond = 1;             % Determines the shape used [LEP (0) or TES (1)]

if Shape_cond == 0          % LEP
    C1 = 2; C2 = 50; C3 = 0; C4 = 0; C5 = 0;    % LEP Polynomial Coefficients
end

if Shape_cond == 1          % TES
    payload_r = (0.0640/2);                     % Payload radius [Meters]
    b = 1;                                      % TES Factor [0, 1.5]
    TEP_offset = 1.2;                           % offset > 1
end

span = 0.198;                                   % Span of the Vehicle [Meters]
round_cond = true;                              % Boolean (true/false) deciding whether the leading edge is round or not
edge_radius = 2;                                % Radius of the rounded edge [Millimeters]
num_circle_points = 8;                          % Number of points per circle / arc

Aft_cond = true;                                % Boolean deciding whether there is an aft body or not
Aft_length = 0.2;                               % Length of the extruded Aft-body
Aft_rows = 5;                                   % Number of aft-body rows

filename = 'Waverider_ex';
%================%

%=====Graphing Inputs=====%
% Not needed for generation / only for development and debugging
check_cone = false;                  % Graphing parameter for shockcone
check_prescaled = false;             % Graphing parameter for 2D LEP projection
check_mainbody = false;              % Graphing parameter for all preprocessed points
check_seedpoint_process = false;    % Graphing parameter for processed points
check_mesh_viz = false;             % Graphing parameter for meshed surfaces
check_final_mesh_viz = true;        % Graphing parameter for final meshed surfaces
%=========================%

% Sets the output location of the STL file in a folder called "Output"
outputDir = fullfile(fileparts(mfilename('fullpath')), 'Output');
if ~exist(outputDir, 'dir')     % checks if the folder exists
    mkdir(outputDir);           % creates the folder if not
end

% Append filename for differing generation
if round_cond == false
    % Add '_sharp.stl' to the filename
    filename = append(filename, '_sharp.stl');
else
    % Add '_round.stl' to the filename
    filename = append(filename, '_round.stl');
end

% File path used by stlwrite(TR, filepath, 'binary/text')
filepath = fullfile(outputDir, filename);

%% Setting up the Cone flow field

% Initial velocities behind the shock
[Vel_radial, Vel_theta] = Initial_Cond(beta, M1, gamma);

% Phase 1: External flow (from shock to cone surface)
Vr = [];
Vtheta = [];
theta_vals = [];
Mat_V = [Vel_radial; Vel_theta];
rad_theta = deg2rad(beta);
Cone_Angle = NaN;

while true
    dV = Taylor_Maccoll_Solver(Mat_V, gamma, rad_theta);
    Mat_V = Mat_V + h * dV;
    rad_theta = rad_theta + h;
    
    Vr(end+1) = Mat_V(1);
    Vtheta(end+1) = Mat_V(2);
    theta_vals(end+1) = rad_theta;
    
    if isnan(Cone_Angle) && Vtheta(end) > 0
        Cone_Angle = rad_theta - h;
        fprintf('Cone angle is: %g deg\n', rad2deg(Cone_Angle));
        break;
    end
end

%% Edge Construction
%  Leading Edge Polynomial Construction and Projection
if Shape_cond == 0
    % Azimuth angle range from 0 to 2pi around the z-axis
    phi = linspace(0, 2*pi, 360);
    
    x_LEP_prescaled = linspace(-span*0.5, span*0.5, seed_num);
    
    % Next we need to plug in the prescaled X values to our LEP
    z_LEP_prescaled = C5*x_LEP_prescaled.^8 + C4*x_LEP_prescaled.^6 + C3*x_LEP_prescaled.^4 + C2*x_LEP_prescaled.^2 + C1;

    % Calculate the prescaled Y values
    y_LEP_prescaled = sqrt(z_LEP_prescaled.^2 * tand(beta)^2 - x_LEP_prescaled.^2);
    LEP_points = [x_LEP_prescaled; y_LEP_prescaled; z_LEP_prescaled];
    
    % Calculate the Planform Area
    Box_area = span*max(z_LEP_prescaled);    % Area of the box
    a_area = ((1/9)*C5*((span*0.5)^9) + (1/7)*C4*((span*0.5)^7) + (1/5)*C3*((span*0.5)^5) + (1/3)*C2*((span*0.5)^3) + C1*(span*0.5));
    b_area = ((1/9)*C5*((-span*0.5)^9) + (1/7)*C4*((-span*0.5)^7) + (1/5)*C3*((-span*0.5)^5) + (1/3)*C2*((-span*0.5)^3) + C1*(-span*0.5));
    Curve_area = a_area - b_area;           % Area under the LEP
    Planform_Area = Box_area - Curve_area;  % Planform Area (m^2)
    Planform_Area_cm = Planform_Area * 100^2;
    fprintf(['=======\n' ...
        'LEP SET\n' ...
        '=======\n\n'])
    fprintf(['=======\n' ...
        'Planform Area of the Waverider: %g m^2 (%g cm^2)\n' ...
        '=======\n\n'], Planform_Area, Planform_Area_cm)
end

% Top Edge Shape Construction and Projection
if Shape_cond == 1
    x_LEP_prescaled = linspace(-span*0.5, span*0.5, seed_num);
    y_LEP_prescaled = TEP_offset*payload_r - (b*payload_r*exp(-0.5*(x_LEP_prescaled/payload_r).^2) + (1-b)*(-(1/(2*payload_r))*x_LEP_prescaled.^2 + payload_r));
    z_LEP_prescaled = sqrt(x_LEP_prescaled.^2 + y_LEP_prescaled.^2)/(tand(beta));
    LEP_points = [x_LEP_prescaled; y_LEP_prescaled; z_LEP_prescaled];
end

%% Shockcone
if check_cone == true
    % Redefine cone_height
    shockcone_height = max(z_LEP_prescaled);
    n_shockcone = 50;          % Cone mesh resolution
    phi = linspace(0, 2*pi, 360);
    
    % Grid in z and azimuth
    z_shockcone = linspace(0, shockcone_height, n_shockcone); 
    [Z_shockcone, PHI] = meshgrid(z_shockcone, phi);    
    
    % Compute corresponding radial distance
    R_shockcone = Z_shockcone * tand(beta);
    
    % Convert to Cartesian
    X_shockcone = R_shockcone .* cos(PHI);
    Y_shockcone = R_shockcone .* sin(PHI);

    if check_prescaled == true
        figure;
        surf(X_shockcone, Y_shockcone, Z_shockcone, 'FaceAlpha', 0.5)
        hold on;
        plot3(x_LEP_prescaled, y_LEP_prescaled, z_LEP_prescaled, '.b')
        grid on; axis equal;
        title('TEP Shape and Shockcone')
        xlabel('X-axis')
        ylabel('Y-axis')
        zlabel('Z-axis')
        shading interp
        colormap sky
    end
end
%% Surface Streamline Interpolation and Tracing
% Preallocate a 3 by n array that will store x y z points for the top
% surface. This array will be dynamically allocated due to it's unknown
% size.

SSF = 2;    % Step safety factor (Dubbed by the honorable Kenshiro Lim)

% Mesh and spline resolution
mesh_res = ceil(seed_num / 2);
spline_step = (max(z_LEP_prescaled)-min(z_LEP_prescaled)) / (SSF*mesh_res);

all_samples = (((seed_num - 1) / 2) - abs((1:seed_num)-(seed_num + 1) / 2)) + 1;   % number of samples corresponding to each seed point

% Initialize an array to hold all angles in radians and r values
all_rho = atan2(y_LEP_prescaled, x_LEP_prescaled);
all_theta = -1 * ones(mesh_res, seed_num);
all_r = -1 * ones(mesh_res, seed_num);

fprintf('Generating bottom surface points...\n')
% Fill in the theta and r arrays
for i = 1:seed_num
    % Calculate the seed point / first point in the streamline's r and
    % theta values
    ith_r = sqrt(x_LEP_prescaled(i)^2 + y_LEP_prescaled(i)^2 + z_LEP_prescaled(i)^2);
    ith_theta = atan(sqrt(x_LEP_prescaled(i)^2 + y_LEP_prescaled(i)^2) / z_LEP_prescaled(i));
   
    % Insert the seed points into the first column
    all_theta(1, i) = ith_theta; 
    all_r(1, i) = ith_r;

    % Starting r and theta values
    curr_r = ith_r;
    curr_theta = ith_theta;

    % Empty array of spline points
    spline_r = [ith_r];
    spline_theta = [ith_theta];

    % target z height for the back surface
    z_target = max(z_LEP_prescaled);
    
    while true
        % Interpolate the velocities at the given theta
        Vr_curr = interp1(theta_vals, Vr, curr_theta, 'spline', 'extrap');
        Vtheta_curr = interp1(theta_vals, Vtheta, curr_theta, 'spline', 'extrap');

        % Save current state before stepping
        prev_r = curr_r;
        prev_theta = curr_theta;
        prev_z = prev_r * cos(prev_theta);

        % Step the radial and theta components
        curr_r = curr_r + Vr_curr * spline_step;
        curr_theta = curr_theta + Vtheta_curr * spline_step / curr_r; 
        curr_z = curr_r * cos(curr_theta);

        % Normal case: append point
        spline_r = [spline_r curr_r];
        spline_theta = [spline_theta curr_theta];

        % Check if overshoots target z
        if curr_z >= z_target
            % Interpolation factor to exactly hit z_target
            factor = (z_target - prev_z) / (curr_z - prev_z);

            % Compute final point exactly at z_target
            final_r = prev_r + factor * (curr_r - prev_r);
            final_theta = prev_theta + factor * (curr_theta - prev_theta);

            % Append the new final point at the target z height
            spline_r = [spline_r final_r];
            spline_theta = [spline_theta final_theta];

            break; % Done with this streamline
        end
    end

    % Define sampling points inside the spline
    num_points = all_samples(i);

    % Creates an array of num_points evenly spaced from ith_r to the
    % end point of the ith LEP seed point streamline
    r_points = linspace(ith_r, final_r, num_points);
    % Initialize theta_points
    theta_points = zeros(1, num_points);

    sample_index = 1;
    for r_sample = r_points
        r_ind = 1;
        while spline_r(r_ind) <= r_sample && r_ind < length(spline_r)
            r_ind = r_ind + 1;
        end

        if r_ind == 1
            r_ind = 2;
        end

        theta_inter = (r_sample - spline_r(r_ind-1)) / (spline_r(r_ind) - spline_r(r_ind-1));
        theta_sample = spline_theta(r_ind-1) + theta_inter*(spline_theta(r_ind) - spline_theta(r_ind-1));

        theta_points(sample_index) = theta_sample;
        sample_index = sample_index + 1;
    end

    all_r(1:num_points, i) = r_points;
    all_theta(1:num_points, i) = theta_points;
    fprintf('Progress on bottom generation: %g%%\n', (i/seed_num) * 100)
end
fprintf('Generating bottom surface points [DONE] \n')

%% Cylindrical to Cartesian the Streamlines
topSurfacePoints = [];     % Initialize array for top surface points
bottomSurfacePoints = [];     % Initialize array for bottom surface points
fprintf('Converting bottom surface points...\n')
for i = 1:seed_num
    % Initialize empty arrays for each seed point/streamline trace
    all_x = [];
    all_y = [];
    all_z = [];
    % Convert each valid point
    for j = 1:mesh_res
        if all_r(j, i) > 0 && all_theta(j, i) > 0   % Ignore the -1 in the array
            x_ij = all_r(j, i) * sin(all_theta(j, i)) * cos(all_rho(i));
            y_ij = all_r(j, i) * sin(all_theta(j, i)) * sin(all_rho(i));
            z_ij = all_r(j, i) * cos(all_theta(j, i));
            all_x = [all_x x_ij];
            all_y = [all_y y_ij];
            all_z = [all_z z_ij];
        end
    end
    bottom_array = [all_x; all_y; all_z];
    bottomSurfacePoints = [bottomSurfacePoints bottom_array];
    fprintf('Progress on bottom conversion: %g%%\n', (i/seed_num) * 100)
end

% Set the z height of the back surface points as z_target
for i = 1:seed_num
    rear_index = sum(all_samples(1:i));
    bottomSurfacePoints(3, rear_index) = z_target;
end

fprintf('Converting bottom surface points [DONE] \n')

%% Top Surface Code
fprintf('Generating top surface cartesian points...\n')
if round_cond == false   % Sharp Edge
    for i = 1:seed_num
        % Use original LEP points
        x_start = x_LEP_prescaled(i);
        y_start = y_LEP_prescaled(i);
        z_start = z_LEP_prescaled(i);
    
        % Final z target for top surface extrusion
        z_target = max(z_LEP_prescaled);  % You can change if you'd like a longer extrusion
    
        % Number of samples along top streamline (reuse all_samples to match)
        num_points = all_samples(i);
    
        % Linearly spaced z points
        z_points = linspace(z_start, z_target, num_points);
    
        % x and y stay constant
        % Free streamlines (mach wave - lowest drag - theory only)
        x_points = x_start * ones(1, num_points);
        y_points = y_start * ones(1, num_points);
    
        % Combine into array
        top_array = [x_points; y_points; z_points];
    
        % Append to overall top surface array
        topSurfacePoints = [topSurfacePoints top_array];
    
        fprintf('Progress top generation (Sharp): %g%%\n', (i/seed_num) * 100)
    end
else                % Rounded Edge
    Shifted_LEP = [];
    chord = 2*(edge_radius/1000);
    for i = 1:seed_num
        % Use original LEP points
        x_start = x_LEP_prescaled(i);
        y_start = y_LEP_prescaled(i) - chord;
        z_start = z_LEP_prescaled(i);
        shifted_points = [x_start; y_start; z_start];
        Shifted_LEP = [Shifted_LEP shifted_points];
    
        % Final z target for top surface extrusion
        z_target = max(z_LEP_prescaled);  % You can change if you'd like a longer extrusion
    
        % Number of samples along top streamline (reuse all_samples to match)
        num_points = all_samples(i);

        % Linearly spaced z points
        z_points = linspace(z_start, z_target, num_points);

        % x and y points
        x_points = x_start * ones(1, num_points);
        y_points = y_start * ones(1, num_points);
    
        % Combine into array
        top_array = [x_points; y_points; z_points];
    
        % Append to overall top surface array
        topSurfacePoints = [topSurfacePoints top_array];
    
        fprintf('Progress top generation (Round): %g%%\n', (i/seed_num) * 100)
    end

    % Generate Rounded Edge
    % For each seed point, find the plane the rounded filet is drawn on
    % The first and last seed points should always be on the x-y plane
    % manually do the first and last filets outside of the for loop

    % All other filets must be inside the plane created by the vector norms
    % of the LEPs

    % Non-Constant Spacing Version
    % Highlights the first two points per LEP point
    j = 0; k = 2;
    Seed_point = []; Second_point = [];
    % T_vectors = []; 
    % S_vectors = []; 
    N_vectors = [];
    for i = 1:floor(seed_num/2)
        num_points = all_samples(i);
        % Seed point
        p1 = topSurfacePoints(:, j+1);
        % Point next to the seed point
        p2 = topSurfacePoints(:, j+1+k);
        % Local surface tangent
        T = (p2 - p1) / vecnorm(p2 - p1);
        % Local edge wise vector
        S = (Shifted_LEP(:, i+1) - Shifted_LEP(:, i)) / vecnorm(Shifted_LEP(:, i+1) - Shifted_LEP(:, i));
        % Local Normal
        % N = cross(S, T) / vecnorm(cross(S, T));
        N = cross(S, [0; -1; 0]) / vecnorm(cross(S, [0; -1; 0]));
    
        j = j + num_points;
        k = k + 1;

        Seed_point = [Seed_point p1];
        Second_point = [Second_point p2];

        % % Local Surface tangent vector
        % T_vectors = [T_vectors T];
        % % Leading edge tangent vector
        % S_vectors = [S_vectors S];
        % Local Surface normal vector
        N_vectors = [N_vectors N];
    end

    % Middle point detect
    mid_cond = ceil(seed_num/2) - floor(seed_num/2);
    % If the middle point exists (odd seed_num)
    if mid_cond ~= 0
        N = [0; 0; -1]; % Vector points straight into freestream
        N_vectors = [N_vectors N];
        
        % Seed point
        p1 = topSurfacePoints(:, j+1);
        % Point next to the seed point
        p2 = topSurfacePoints(:, j+1+k);

        % Projected T vector only for the middle
        Seed_point = [Seed_point p1];
        Second_point = [Second_point p2];
    end

    % Projected T vector
    Virtual_point = Second_point;
    Virtual_point(2, :) = Seed_point(2, :);

    m = [];
    for i = 1:ceil(seed_num/2)
        rise = norm(Second_point(:,i)-Virtual_point(:,i));
        run = norm(Virtual_point(:,i) - Seed_point(:,i));
        m = [m rise/run];
    end

    filet_r = chord ./ (2*cos(atan(m)));
    x_offset = -(m.*filet_r) ./ sqrt(1 + m.^2);

    filet_origin = Seed_point;
    for i = 1:ceil(seed_num/2)
        if i == 1
            % First fillet in xy-plane (z = 0)
            filet_origin(1, i) = Seed_point(1, i) - x_offset(i);
            filet_origin(2, i) = Seed_point(2, i) + (chord/2);
        else
            % Displace fillet origin along outward normal
            filet_origin(1, i) = Seed_point(1, i) + x_offset(i) * N_vectors(1, i);
            filet_origin(2, i) = Seed_point(2, i) + (chord/2);
            % Adjust z-coordinate using outward normal
            filet_origin(3, i) = Seed_point(3, i) + x_offset(i) * N_vectors(3, i);
        end
    end

    rounded_edge_points = [];
    for i = 1:floor(seed_num/2)
        arc_points = generate3DArcV2(Shifted_LEP(:, i), LEP_points(:, i), filet_origin(:, i), N_vectors(:,i), num_circle_points);
        rounded_edge_points = [rounded_edge_points, arc_points];
    end

    % Round the middle point/arc
    if mid_cond ~= 0
        arc_points = generate3DArcV2(Shifted_LEP(:, ceil(seed_num/2)), LEP_points(:, ceil(seed_num/2)), filet_origin(:, ceil(seed_num/2)),  N_vectors(:,ceil(seed_num/2)), num_circle_points);
        rounded_edge_points = [rounded_edge_points, arc_points];
    end

    % Reflects the points across the x-axis
    fliped_side = flip(rounded_edge_points(:, 1:end-num_circle_points), 2);
    fliped_side(1, :) = -1*fliped_side(1, :);

    % Flips every num_circle_points chunk of points to align the points for
    % meshing later
    for i = 1:size(fliped_side, 2)/num_circle_points
        start_col = (i-1)*num_circle_points + 1;
        end_col = i*num_circle_points;
        fliped_side(:, start_col:end_col) = fliped_side(:, end_col:-1:start_col);
    end

    % Append the other side of the waverider's rounded edge
    rounded_edge_points = [rounded_edge_points fliped_side];

    % Remove bottom seeds after appending
    rounded_edge_seedpoints_bot = num_circle_points:num_circle_points:size(rounded_edge_points,2);
    rounded_edge_points(:, rounded_edge_seedpoints_bot) = [];
end
fprintf('Generating top surface points [DONE] \n')

%% Plot the waverider points
if check_mainbody == true
    figure;
    % Original LEP Line
    plot3(LEP_points(1, :), LEP_points(2, :), LEP_points(3, :), '-k')
    hold on; 
    axis equal;
    % Surfaces
    plot3(bottomSurfacePoints(1,:), bottomSurfacePoints(2,:), bottomSurfacePoints(3,:), '.r')
    plot3(topSurfacePoints(1, :), topSurfacePoints(2, :), topSurfacePoints(3, :), '.b')
    % Rounded Surface
    if round_cond == true
        plot3(rounded_edge_points(1,:), rounded_edge_points(2,:), rounded_edge_points(3,:), '.g', 'LineWidth', 1)
        legend('LEP', 'Bottom Surface', 'Top Surface', 'Rounded Edge')
    else
        legend('LEP', 'Bottom Surface', 'Top Surface')
    end
    if check_cone == true
        surf(X_shockcone, Y_shockcone, Z_shockcone, 'FaceAlpha', 0.5)
        shading interp
        colormap sky
    end
    xlabel('X (m)')
    ylabel('Y (m)')
    zlabel('Z (m)')
    title('Generated Waverider Points Riding Shockwave')
    shading interp
    colormap sky
    grid on
end

%% Check if the waverider is valid or not
% At this point we have "topSurfacePoints" and "bottomSurfacePoints"
% Given that y = sqrt(z.^2 * tand(beta)^2 - x.^2) you can filter
% out points by plugging in x and z points, finding what the y of the LEP
% (minimum y value) and comparing the actual y of the point to filter out 
% any overlapping or impossible points.

% The y of the point should always be greater than the LEP y value at that point
if round_cond == true
    % This creates an array of y values
    if Shape_cond == 0
        z_of_x = C5*bottomSurfacePoints(1,:).^8 + C4*bottomSurfacePoints(1,:).^6 + C3*bottomSurfacePoints(1,:).^4 + C2*bottomSurfacePoints(1,:).^2 + C1;
        y_min = sqrt(z_of_x.^2 * tand(beta)^2 - bottomSurfacePoints(1,:).^2);
    end

    if Shape_cond == 1
        y_min = TEP_offset*payload_r - (b*payload_r*exp(-0.5*(bottomSurfacePoints(1, :)/payload_r).^2) + (1-b)*(-(1/(2*payload_r))*bottomSurfacePoints(1, :).^2 + payload_r));
    end
    % Adjust min y values accordingly to the rounded edge condition
    y_min = y_min - chord;
    % Compare y_min and bottomSurfacePoints(2,:) (actual y points)
    validCond = bottomSurfacePoints(2,:) >= y_min;
    
    if any(~validCond)
        fprintf('The waverider geometry is impossible :( \n')
        return;
    else
        fprintf('The waverider geometry is valid and possible :) \n')
    end

else
    fprintf('The waverider geometry is sharp. \n')
end

%% Point Processing
% This section is used to edit the points such that there are no overlapping
% points such as points along the LEP aka. seed points as well as points on
% the edges of the rounded section

% After point removal, all of the point data for the waverider will be in a
% single array which has no duplicates.

% We will rely upon seed points on the bottom surface of the waverider for
% all meshing going forwards

% Points to remove:
% LEP/Seed points on the bottom edge of the rounded points
%       This de-conflicts the bottom seed points with the rounded edge
%       while maintaining the ability to run sharp waveriders

% LEP/Seed points on the top surface
%       This de-conflicts the top seed points with the rounded edge while
%       maintaining the ability to run sharp waveriders. Top edge rounded
%       points will remain to serve as seed points for the top surface for
%       rounded meshes.

% Point Array structure:
%   Sharp - [Bottom Top]
%   Round - [Bottom Rounded Top]

fprintf('Start Removing Duplicate Seed Points! \n')

% Initialize the master point array first with the bottom surface
all_points = bottomSurfacePoints;

% Find the seed points in the bottom surface and store it for later use in
% meshing the bottom surface and rounded edge
bottomSurface_seedpoints = [];
next_num = 0;
for i = 1:seed_num      % find the seed point indexes
    if i <= seed_num/2
        bottomSurface_seedpoints = [bottomSurface_seedpoints sum(all_samples(1:i-1)) + 1];
        next_num = next_num + 1;
    else
        next_num = next_num - 1;
        bottomSurface_seedpoints = [bottomSurface_seedpoints sum(all_samples(1:i-1)) + 1];
    end
end

% Save the range of bottom surface points
bottomSurface_range = 1:length(all_points);

% Next begin processing the rounded edge points if they exist
if round_cond == true
    start_round_edge = length(all_points)+1;    % Starting index of the rounded edge surface points
    % No additional removal here, as it's already done before point processing
    % Store for later when meshing the top surface
    arc_length = num_circle_points - 1;
    rounded_edge_seedpoints_top = start_round_edge + (0:seed_num-1)*arc_length;
    % Append to the total array
    all_points = [all_points rounded_edge_points];
    % Index range of rounded edge surface points
    round_edge_range = start_round_edge:length(all_points);
end

% Process top surface points
topSurface_seedpoints = [];
start_topSurface = length(all_points)+1;    % Starting index of the top surface points
next_num = 0;
for i = 1:seed_num      % find the seed point indexes
    if i <= seed_num/2
        topSurface_seedpoints = [topSurface_seedpoints sum(all_samples(1:i-1)) + 1];
        next_num = next_num + 1;
    else
        next_num = next_num - 1;
        topSurface_seedpoints = [topSurface_seedpoints sum(all_samples(1:i-1)) + 1];
    end
end
topSurfacePoints(:, topSurface_seedpoints) = [];        % Delete top surface seedpoints
all_points = [all_points topSurfacePoints];
% Index range of top surface points
topSurface_range = start_topSurface:length(all_points);

if check_seedpoint_process == true
    figure;
    plot3(all_points(1,:), all_points(2,:), all_points(3,:), '.k')
    hold on; axis equal;
    plot3(all_points(1,bottomSurface_seedpoints), all_points(2,bottomSurface_seedpoints), all_points(3,bottomSurface_seedpoints), 'or')
    if round_cond == true
        plot3(all_points(1,rounded_edge_seedpoints_top), all_points(2,rounded_edge_seedpoints_top), all_points(3,rounded_edge_seedpoints_top), 'ob')
    end
    xlabel('X (m)')
    ylabel('Y (m)')
    zlabel('Z (m)')
    title('Processed Waverider Points - Duplicate Seep Points Removed')
    shading interp
    colormap sky
    grid on
end

fprintf('Removing Duplicate Seed Points [DONE] \n')

%% Back/Aft Body Points
% If an aft body is to be generated given the condition is set to true,
% then at the end, the aft body points will be appended to all_points where
% the structure of the array will now be:

% Point Array structure:
%   Sharp - [Bottom Top Aft]
%   Round - [Bottom Rounded Top Aft]

fprintf(['==========\n' ...
'Generating Aft Surface...\n'])
aft_points = [];    % Will contain all of the aft surface points

% Pick out the trailing points of the bottom surface
trail_bot_sum = [];
trail_bot_range = [];
for i = 1:seed_num
    trail_bot_range = [trail_bot_range sum(all_samples(1:i))];
    x_trail_bot = all_points(1, trail_bot_range(i));
    y_trail_bot = all_points(2, trail_bot_range(i));
    z_trail_bot = all_points(3, trail_bot_range(i));
    trail_bot = [x_trail_bot; y_trail_bot; z_trail_bot];
    trail_bot_sum = [trail_bot_sum trail_bot];
    aft_points = [aft_points trail_bot];
end

% Pick out the trailing points of the rounded edges
if round_cond == true
    % left most node
    node1_range = start_round_edge:length(bottomSurfacePoints) + (num_circle_points-1);
    % right most node
    node2_range = start_round_edge + (seed_num-1)*(num_circle_points-1):length(bottomSurfacePoints)+seed_num*(num_circle_points-1);

    x_trail_node1 = all_points(1, node1_range);
    y_trail_node1 = all_points(2, node1_range);
    z_trail_node1 = all_points(3, node1_range);
    trail_node1 = [x_trail_node1; y_trail_node1; z_trail_node1];

    x_trail_node2 = all_points(1, node2_range);
    y_trail_node2 = all_points(2, node2_range);
    z_trail_node2 = all_points(3, node2_range);
    trail_node2 = [x_trail_node2; y_trail_node2; z_trail_node2];
    
    aft_points = [aft_points trail_node1 trail_node2];

    % Pick out trailing top surface points
    trail_top_sum = [];
    trail_top_range = [];
    top_col_num = seed_num-2;
    top_samples = (((top_col_num - 1) / 2) - abs((1:top_col_num)-(top_col_num + 1) / 2)) + 1;   % number of samples corresponding to each seed point
    for i = 1:top_col_num
        trail_top_range = [trail_top_range start_topSurface-1 + sum(top_samples(1:i))];
        x_trail_top = all_points(1, trail_top_range(i));
        y_trail_top = all_points(2, trail_top_range(i));
        z_trail_top = all_points(3, trail_top_range(i));
        trail_top = [x_trail_top; y_trail_top; z_trail_top];
        trail_top_sum = [trail_top_sum trail_top];
        aft_points = [aft_points trail_top];
    end

else    % Sharp case
    % Pick out trailing top surface points in the sharp case
    trail_top_sum = [];
    trail_top_range = [];
    top_col_num = seed_num-2;
    top_samples = (((top_col_num - 1) / 2) - abs((1:top_col_num)-(top_col_num + 1) / 2)) + 1;   % number of samples corresponding to each seed point
    for i = 1:top_col_num
        trail_top_range = [trail_top_range start_topSurface-1 + sum(top_samples(1:i))];
        x_trail_top = all_points(1, trail_top_range(i));
        y_trail_top = all_points(2, trail_top_range(i));
        z_trail_top = all_points(3, trail_top_range(i));
        trail_top = [x_trail_top; y_trail_top; z_trail_top];
        trail_top_sum = [trail_top_sum trail_top];
        aft_points = [aft_points trail_top];
    end
end

if Aft_cond == true
    % Generate the extruded aft points
    d_row = Aft_length/Aft_rows;
    added_aft_points = [];
    for i = 1:Aft_rows
        x_aft = aft_points(1, :);
        y_aft = aft_points(2, :);
        z_aft = aft_points(3, :) + i*d_row;
        xyz_aft = [x_aft; y_aft; z_aft];
        added_aft_points = [added_aft_points xyz_aft];
    end

    % Append the aft points to the rest of the array
    all_points = [all_points added_aft_points];
end
fprintf(['Generating Aft Surface [DONE]\n' ...
'==========\n'])
%% Mesh the bottom surface
fprintf(['==========\n' ...
    'Generating Bottom Surface Mesh...\n'])

% Use global all_points as vertices
vertices = all_points';

% Define index_maps for bottom streamlines
index_maps_bottom = cell(1, seed_num);
current_idx = 1;
for i = 1:seed_num
    num_pts = all_samples(i);
    index_maps_bottom{i} = current_idx:(current_idx + num_pts - 1);
    current_idx = current_idx + num_pts;
end

% Build faces for bottom (uniform order)
bottom_faces = [];
for i = 1:(seed_num-1)
    idx1 = index_maps_bottom{i};
    idx2 = index_maps_bottom{i+1};
    len1 = length(idx1);
    len2 = length(idx2);
    p1 = 1;
    p2 = 1;
    while p1 < len1 && p2 < len2
        v1 = idx1(p1);
        v1_next = idx1(p1+1);
        v2 = idx2(p2);
        v2_next = idx2(p2+1);
        f1_next = (p1+1)/len1;
        f2_next = (p2+1)/len2;
        if f1_next < f2_next
            bottom_faces = [bottom_faces; v1 v1_next v2];
            p1 = p1 + 1;
        else
            bottom_faces = [bottom_faces; v1 v2 v2_next];
            p2 = p2 + 1;
        end
    end
    while p1 < len1
        v1 = idx1(p1);
        v1_next = idx1(p1+1);
        v2 = idx2(end);
        bottom_faces = [bottom_faces; v1 v1_next v2];
        p1 = p1 + 1;
    end
    while p2 < len2
        v1 = idx1(end);
        v2 = idx2(p2);
        v2_next = idx2(p2+1);
        bottom_faces = [bottom_faces; v1 v2 v2_next];
        p2 = p2 + 1;
    end
end

% Visualization
if check_mesh_viz == true
    figure;
    trisurf(bottom_faces, vertices(:,1), vertices(:,2), vertices(:,3), ...
        'FaceColor', 'cyan', 'EdgeColor', 'k')
    axis equal
    xlabel('X'); ylabel('Y'); zlabel('Z')
    title('Waverider Bottom Surface Mesh')
end

fprintf(['Generating Bottom Surface Mesh [DONE]\n' ...
    '==========\n'])
%% Mesh the rounded edge
if round_cond == true
    fprintf(['==========\n' ...
        'Generating Rounded Edge Mesh...\n'])

    % Define index_maps for rounded arcs, appending bottom seed
    arc_length = num_circle_points - 1;
    index_maps_arc = cell(1, seed_num);
    for i = 1:seed_num
        start_idx = start_round_edge + (i - 1) * arc_length;
        arc_indices = start_idx:(start_idx + arc_length - 1);
        index_maps_arc{i} = [arc_indices bottomSurface_seedpoints(i)];
    end

    % Build faces for rounded edge (same uniform order)
    arc_faces = [];
    for i = 1:(seed_num-1)
        idx1 = index_maps_arc{i};
        idx2 = index_maps_arc{i+1};
        len1 = length(idx1);
        len2 = length(idx2);
        p1 = 1;
        p2 = 1;
        while p1 < len1 && p2 < len2
            v1 = idx1(p1);
            v1_next = idx1(p1+1);
            v2 = idx2(p2);
            v2_next = idx2(p2+1);
            f1_next = (p1+1)/len1;
            f2_next = (p2+1)/len2;
            if f1_next < f2_next
                arc_faces = [arc_faces; v1 v1_next v2];
                p1 = p1 + 1;
            else
                arc_faces = [arc_faces; v1 v2 v2_next];
                p2 = p2 + 1;
            end
        end
        while p1 < len1
            v1 = idx1(p1);
            v1_next = idx1(p1+1);
            v2 = idx2(end);
            arc_faces = [arc_faces; v1 v1_next v2];
            p1 = p1 + 1;
        end
        while p2 < len2
            v1 = idx1(end);
            v2 = idx2(p2);
            v2_next = idx2(p2+1);
            arc_faces = [arc_faces; v1 v2 v2_next];
            p2 = p2 + 1;
        end
    end

    % Visualization with transparency to verify shape
    if check_mesh_viz == true
        figure;
        trisurf(arc_faces, vertices(:,1), vertices(:,2), vertices(:,3), ...
            'FaceColor', 'green', 'EdgeColor', 'k', 'FaceAlpha', 0.5)
        hold on;
        plot3(all_points(1,rounded_edge_seedpoints_top), all_points(2,rounded_edge_seedpoints_top), all_points(3,rounded_edge_seedpoints_top), 'ob', 'MarkerSize', 5)
        plot3(all_points(1,bottomSurface_seedpoints), all_points(2,bottomSurface_seedpoints), all_points(3,bottomSurface_seedpoints), 'or', 'MarkerSize', 5)
        axis equal
        xlabel('X'); ylabel('Y'); zlabel('Z')
        title('Waverider Rounded Edge Mesh with Top (blue) and Bottom (red) Seeds')
        view(3); grid on;
    end
    fprintf(['Generating Rounded Edge Mesh [DONE]\n' ...
    '==========\n'])
end

%% Mesh the top surface
fprintf(['==========\n' ...
    'Generating Top Surface Mesh...\n'])

% Determine seed points for top surface
if round_cond == true
    top_seedpoints = rounded_edge_seedpoints_top; % Use rounded edge seed points for round case
else
    top_seedpoints = bottomSurface_seedpoints;    % Use bottom surface seed points for sharp case
end

% Number of points per top streamline (excluding removed seeds)
num_points_top = all_samples - 1; % Match bottom surface structure

% Define index_maps for top streamlines based on processed all_points
index_maps_top = cell(1, seed_num);
current_idx = topSurface_range(1); % Start from the top surface range base
for i = 1:seed_num
    index_maps_top{i} = top_seedpoints(i); % Start with seed point
    if num_points_top(i) > 0
        start_top_idx = current_idx;
        end_top_idx = current_idx + num_points_top(i) - 1;
        index_maps_top{i} = [index_maps_top{i} start_top_idx:end_top_idx];
        current_idx = current_idx + num_points_top(i);
    end
end

% Build faces for top (uniform order, mirroring bottom surface logic)
top_faces = [];
for i = 1:(seed_num-1)
    idx1 = index_maps_top{i};
    idx2 = index_maps_top{i+1};
    len1 = length(idx1);
    len2 = length(idx2);
    p1 = 1;
    p2 = 1;

    % Special handling for boundaries (first and last streamlines)
    if i == 1
        % Ensure first streamline connects cleanly
        v1 = idx1(1);
        v2 = idx2(1);
        top_faces = [top_faces; v1 v2 idx2(2)]; % Triangle with next point
    end
    if i == seed_num-1
        % Ensure last streamline connects cleanly
        v1 = idx1(1);
        v2 = idx2(1);
        top_faces = [top_faces; v1 v2 idx1(end)]; % Triangle with last point
    end

    while p1 < len1 && p2 < len2
        v1 = idx1(p1);
        v1_next = idx1(p1+1);
        v2 = idx2(p2);
        v2_next = idx2(p2+1);
        f1_next = (p1+1)/len1;
        f2_next = (p2+1)/len2;
        if f1_next < f2_next
            top_faces = [top_faces; v1 v1_next v2];
            p1 = p1 + 1;
        else
            top_faces = [top_faces; v1 v2 v2_next];
            p2 = p2 + 1;
        end
    end
    while p1 < len1
        v1 = idx1(p1);
        v1_next = idx1(p1+1);
        v2 = idx2(end);
        top_faces = [top_faces; v1 v1_next v2];
        p1 = p1 + 1;
    end
    while p2 < len2
        v1 = idx1(end);
        v2 = idx2(p2);
        v2_next = idx2(p2+1);
        top_faces = [top_faces; v1 v2 v2_next];
        p2 = p2 + 1;
    end
end

% Visualization
if check_mesh_viz == true
    figure;
    trisurf(top_faces, vertices(:,1), vertices(:,2), vertices(:,3), ...
        'FaceColor', 'blue', 'EdgeColor', 'k')
    axis equal
    xlabel('X'); ylabel('Y'); zlabel('Z')
    title('Waverider Top Surface Mesh')
end
fprintf(['Generating Top Surface Mesh [DONE]\n' ...
    '==========\n'])
%% Mesh the back/aft surface
if Aft_cond == false
    fprintf(['==========\n' ...
        'Generating Back Surface Mesh...\n'])
    
    % Build faces for back
    back_faces = [];

    % First put in the original back surface indicies
    if round_cond == true
        aft_index = [trail_bot_range node1_range node2_range trail_top_range];
    else
        aft_index = [trail_bot_range trail_top_range];
    end
    % How long the original back surface is (# of points)
    aft_length = length(aft_index);

    if round_cond == true
        % Mesh right node1
        for i = 1:length(node1_range)-1
            R1 = trail_bot_range(1);
            R2 = node1_range(end-i+1);
            R3 = node1_range(end-i);
            back_faces = [back_faces; R1 R2 R3];
        end
        % Mesh left node2
        for i = 1:length(node1_range)-1
            R1 = trail_bot_range(end);
            R2 = node2_range(end-i+1);
            R3 = node2_range(end-i);
            back_faces = [back_faces; R1 R2 R3];
        end
        % Stitch the right corner just after the right node1
        Down1 = trail_bot_range(1);
        Down2 = trail_bot_range(2);
        Up1 = node1_range(1);
        Up2 = trail_top_range(1);
        back_faces = [back_faces; Down1 Up1 Down2; Down2 Up1 Up2];
        % Stitch the left corner just after the left node2
        Down1 = trail_bot_range(end-1);
        Down2 = trail_bot_range(end);
        Up1 = trail_top_range(end);
        Up2 = node2_range(1);
        back_faces = [back_faces; Down1 Up1 Down2; Down2 Up1 Up2];
        % Mesh the middle
        for i = 1:length(trail_top_range)-1
            Down1 = trail_bot_range(i+1);
            Down2 = trail_bot_range(i+2);
            Up1 = trail_top_range(i);
            Up2 = trail_top_range(i+1);
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    else    % Sharp Case
        % Mesh right corner
        R1 = trail_bot_range(1);
        R2 = trail_top_range(1);
        R3 = trail_bot_range(2);
        back_faces = [back_faces; R1 R2 R3];
        % Mesh left corner
        L1 = trail_bot_range(end-1);
        L2 = trail_top_range(end);
        L3 = trail_bot_range(end);
        back_faces = [back_faces; L1 L2 L3];
        % Mesh the middle
        for i = 1:length(trail_top_range)-1
            Down1 = trail_bot_range(i+1);
            Down2 = trail_bot_range(i+2);
            Up1 = trail_top_range(i);
            Up2 = trail_top_range(i+1);
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    end
    
    % Visualization
    if check_mesh_viz == true
        figure;
        trisurf(back_faces, vertices(:,1), vertices(:,2), vertices(:,3), ...
            'FaceColor', 'magenta', 'EdgeColor', 'k')
        xlabel('X'); ylabel('Y'); zlabel('Z')
        title('Waverider Back Surface Mesh')
    end
    
    fprintf(['Generating Back Surface Mesh [DONE]\n' ...
            '==========\n'])

% == AFT SURFACE CASE ==
else
    fprintf(['==========\n' ...
        'Generating Aft Surface Mesh...\n'])
    
    % Build faces for back
    back_faces = [];

    % First put in the original back surface indicies
    if round_cond == true
        aft_index = [trail_bot_range node1_range node2_range trail_top_range];
        
        % Ending index when the waverider ends and the extruded aft surface begins.
        waverider_end = length(bottomSurfacePoints) + length(rounded_edge_points) + length(topSurfacePoints);
    else
        aft_index = [trail_bot_range trail_top_range];

        % Ending index when the waverider ends and the extruded aft surface begins.
        waverider_end = length(bottomSurfacePoints) + length(topSurfacePoints);
    end
    % How long the original back surface is (# of points)
    aft_length = length(aft_index);

    % ==Bottom Surface Stuff==
    % Stitch Node1 to Bot & Bot to Node2
    if round_cond == true
        % Stitch from the original back surface (N1 to Bot)
        Down1 = node1_range(end);
        Down2 = trail_bot_range(1);
        Up1 = (waverider_end)+length(trail_bot_range)+length(node1_range);
        Up2 = (waverider_end+1);
        back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];

        % Stitch from the original back surface (Bot to N2)
        Down1 = trail_bot_range(end);
        Down2 = node2_range(end);
        Up1 = (waverider_end)+length(trail_bot_range);
        Up2 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range);
        back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        % Stitch up the extruded points
        for i = 1:Aft_rows-1
            this_row = (i-1)*aft_length;
            next_row = i*aft_length;
            % (N1 to Bot)
            Down1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+this_row;
            Down2 = (waverider_end+1)+this_row;
            Up1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+next_row;
            Up2 = (waverider_end+1)+next_row;
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
            
            % (Bot to N2)
            Down1 = (waverider_end)+length(trail_bot_range)+this_row;
            Down2 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+this_row;
            Up1 = (waverider_end)+length(trail_bot_range)+next_row;
            Up2 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+next_row;
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    end
    % Vertically merge the original back surface with the extruded points
    for i = 1:length(trail_bot_range)-1
        Down1 = trail_bot_range(i);
        Down2 = trail_bot_range(i+1);
        Up1 = waverider_end+i;
        Up2 = waverider_end+i+1;
        back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
    end
    % Vertically mesh the bottom surface extruded points
    for i = 1:Aft_rows-1
        this_row = (i-1)*aft_length;
        next_row = i*aft_length;
        for ii = 1:length(trail_bot_range)-1
            Down1 = (waverider_end+ii) + this_row;
            Down2 = (waverider_end+ii+1) + this_row;
            Up1 = (waverider_end+ii) + next_row;
            Up2 = (waverider_end+ii+1) + next_row;
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    end

    % ==Top Surface Stuff==
    % Stitch Node1 to Top & Merge Top to Node2
    if round_cond == true
        % Stitch from the original back surface (N1 to Top)
        Down1 = node1_range(1);
        Down2 = trail_top_range(1);
        Up1 = (waverider_end+1)+length(trail_bot_range);
        Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+length(node2_range);
        back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

        % Stitch from the original back surface (Top to N2)
        Down1 = trail_top_range(end);
        Down2 = node2_range(1);
        Up1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+length(trail_top_range);
        Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range);
        back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

        for i = 1:Aft_rows-1
            this_row = (i-1)*aft_length;
            next_row = i*aft_length;

            % Start of Node1 to Start of Top Extrude
            Down1 = (waverider_end+1)+length(trail_bot_range)+this_row;
            Down2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+length(node2_range)+this_row;
            Up1 = (waverider_end+1)+length(trail_bot_range)+next_row;
            Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+length(node2_range)+next_row;
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

            % End of Top to Start of Node2
            Down1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+length(trail_top_range)+this_row;
            Down2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+this_row;
            Up1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+length(trail_top_range)+next_row;
            Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+next_row;
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
        end
    % Stitch Bottom to Top & Top to Bottom
    else    % Sharp case
        % Stitch from the original back surface (Bot to Top)
        Down1 = trail_bot_range(1);
        Down2 = trail_top_range(1);
        Up1 = (waverider_end+1);
        Up2 = (waverider_end+1)+length(trail_bot_range);
        back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

        % Stitch from the original back surface (Top to Bot)
        Down1 = trail_top_range(end);
        Down2 = trail_bot_range(end);
        Up1 = (waverider_end)+length(trail_bot_range)+length(trail_top_range);
        Up2 = (waverider_end)+length(trail_bot_range);
        back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

        for i = 1:Aft_rows-1
            this_row = (i-1)*aft_length;
            next_row = i*aft_length;

            % Start of bottom to Start of Top
            Down1 = (waverider_end+1)+this_row;
            Down2 = (waverider_end+1)+length(trail_bot_range)+this_row;
            Up1 = (waverider_end+1)+next_row;
            Up2 = (waverider_end+1)+length(trail_bot_range)+next_row;
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];

            % End of Top to End of Bottom
            Down1 = (waverider_end)+length(trail_bot_range)+length(trail_top_range)+this_row;
            Down2 = (waverider_end)+length(trail_bot_range)+this_row;
            Up1 = (waverider_end)+length(trail_bot_range)+length(trail_top_range)+next_row;
            Up2 = (waverider_end)+length(trail_bot_range)+next_row;
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
        end
    end

    % Vertically merge the original back surface with the extruded points
    for i = 1:length(trail_top_range)-1
        Down1 = trail_top_range(i);
        Down2 = trail_top_range(i+1);
        if round_cond == true
            displace = length(trail_bot_range) + length(node1_range) + length(node2_range);
            Up1 = waverider_end+i+displace;
            Up2 = waverider_end+i+1+displace;
        else
            displace = length(trail_bot_range);
            Up1 = waverider_end+i+displace;
            Up2 = waverider_end+i+1+displace;
        end
        back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
    end
    % Vertically mesh the top surface extruded points
    for i = 1:Aft_rows-1
        this_row = (i-1)*aft_length;
        next_row = i*aft_length;
        for ii = 1:length(trail_top_range)-1
            if round_cond == true
                displace = length(trail_bot_range) + length(node1_range) + length(node2_range);
                Down1 = (waverider_end+ii) + this_row + displace;
                Down2 = (waverider_end+ii+1) + this_row + displace;
                Up1 = (waverider_end+ii) + next_row + displace;
                Up2 = (waverider_end+ii+1) + next_row + displace;
            else
                displace = length(trail_bot_range);
                Down1 = (waverider_end+ii) + this_row + displace;
                Down2 = (waverider_end+ii+1) + this_row + displace;
                Up1 = (waverider_end+ii) + next_row + displace;
                Up2 = (waverider_end+ii+1) + next_row + displace;
            end
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
        end
    end

    % == Rounded edge stuff ==
    if round_cond == true
        % Vertically mesh the original node1 surface
        for i = 1:length(node1_range)-1
            Down1 = node1_range(i);
            Down2 = node1_range(i+1);
            Up1 = (waverider_end+i)+length(trail_bot_range);
            Up2 = (waverider_end+i+1)+length(trail_bot_range);
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
        % Vertically mesh the extruded node1 surface
        for i = 1:Aft_rows-1
            this_row = (i-1)*aft_length;
            next_row = i*aft_length;
            for ii = 1:length(node1_range)-1
                Down1 = (waverider_end+ii)+length(trail_bot_range)+this_row;
                Down2 = (waverider_end+ii+1)+length(trail_bot_range)+this_row;
                Up1 = (waverider_end+ii)+length(trail_bot_range)+next_row;
                Up2 = (waverider_end+ii+1)+length(trail_bot_range)+next_row;
                back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
            end
        end

        % Vertically mesh the original node2 surface
        for i = 1:length(node2_range)-1
            Down1 = node2_range(i);
            Down2 = node2_range(i+1);
            Up1 = (waverider_end+i)+length(trail_bot_range)+length(node1_range);
            Up2 = (waverider_end+i+1)+length(trail_bot_range)+length(node1_range);
            back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
        end

        % Vertically mesh the extruded node2 surface
        for i = 1:Aft_rows-1
            this_row = (i-1)*aft_length;
            next_row = i*aft_length;
            for ii = 1:length(node2_range)-1
                Down1 = (waverider_end+ii)+length(trail_bot_range)+length(node1_range)+this_row;
                Down2 = (waverider_end+ii+1)+length(trail_bot_range)+length(node1_range)+this_row;
                Up1 = (waverider_end+ii)+length(trail_bot_range)+length(node1_range)+next_row;
                Up2 = (waverider_end+ii+1)+length(trail_bot_range)+length(node1_range)+next_row;
                back_faces = [back_faces; Down1 Down2 Up2; Down1 Up2 Up1];
            end
        end
    end

    % == Displaced Back Surface Stuff ==
    if round_cond == true
        % Rearmost Surface
        Rear_Surf = (Aft_rows-1)*aft_length;
        % Mesh right node1
        for i = 1:length(node1_range)-1
            R1 = (waverider_end+1)+Rear_Surf;
            R2 = (waverider_end+1-i)+length(trail_bot_range)+length(node1_range)+Rear_Surf;
            R3 = (waverider_end-i)+length(trail_bot_range)+length(node1_range)+Rear_Surf;
            back_faces = [back_faces; R1 R2 R3];
        end
        % Mesh left node2
        for i = 1:length(node1_range)-1
            R1 = (waverider_end)+length(trail_bot_range)+Rear_Surf;
            R2 = (waverider_end+1-i)+length(trail_bot_range)+length(node1_range)+length(node2_range)+Rear_Surf;
            R3 = (waverider_end-i)+length(trail_bot_range)+length(node1_range)+length(node2_range)+Rear_Surf;
            back_faces = [back_faces; R1 R2 R3];
        end
        % Stitch the right corner just after the right node1
        Down1 = (waverider_end+1)+Rear_Surf;
        Down2 = (waverider_end+2)+Rear_Surf;
        Up1 = (waverider_end+1)+length(trail_bot_range)+Rear_Surf;
        Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+length(node2_range)+Rear_Surf;
        back_faces = [back_faces; Down1 Up1 Down2; Down2 Up1 Up2];
        % Stitch the left corner just after the left node2
        Down1 = (waverider_end-1)+length(trail_bot_range)+Rear_Surf;
        Down2 = (waverider_end)+length(trail_bot_range)+Rear_Surf;
        Up1 = (waverider_end)+length(trail_bot_range)+length(node1_range)+length(node2_range)+length(trail_top_range)+Rear_Surf;
        Up2 = (waverider_end+1)+length(trail_bot_range)+length(node1_range)+Rear_Surf;
        back_faces = [back_faces; Down1 Up1 Down2; Down2 Up1 Up2];
        % Mesh the middle
        for i = 1:length(trail_top_range)-1
            Down1 = (waverider_end+1+i)+Rear_Surf;
            Down2 = (waverider_end+2+i)+Rear_Surf;
            Up1 = (waverider_end+i)+length(trail_bot_range)+length(node1_range)+length(node2_range)+Rear_Surf;
            Up2 = (waverider_end+i+1)+length(trail_bot_range)+length(node1_range)+length(node2_range)+Rear_Surf;
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    else
        % Rearmost Surface
        Rear_Surf = (Aft_rows-1)*aft_length;
        % Mesh right corner
        R1 = (waverider_end+1)+Rear_Surf;
        R2 = (waverider_end+1)+length(trail_bot_range)+Rear_Surf;
        R3 = (waverider_end+2)+Rear_Surf;
        back_faces = [back_faces; R1 R2 R3];
        % Mesh left corner
        L1 = (waverider_end+length(trail_bot_range)-1)+Rear_Surf;
        L2 = (waverider_end)+length(trail_bot_range)+length(trail_top_range)+Rear_Surf;
        L3 = (waverider_end+length(trail_bot_range))+Rear_Surf;
        back_faces = [back_faces; L1 L2 L3];
        % Mesh the middle
        for i = 1:length(trail_top_range)-1
            Down1 = (waverider_end+1+i)+Rear_Surf;
            Down2 = (waverider_end+2+i)+Rear_Surf;
            Up1 = (waverider_end+i)+length(trail_bot_range)+Rear_Surf;
            Up2 = (waverider_end+i+1)+length(trail_bot_range)+Rear_Surf;
            back_faces = [back_faces; Down1 Up1 Up2; Down1 Up2 Down2];
        end
    end

    if check_mesh_viz == true
        figure;
        trisurf(back_faces, vertices(:,1), vertices(:,2), vertices(:,3), ...
            'FaceColor', 'blue', 'EdgeColor', 'k')
        axis equal
        xlabel('X'); ylabel('Y'); zlabel('Z')
        title('Waverider Aft Surface Mesh')
    end

    fprintf(['Generating Aft Surface Mesh [DONE]\n' ...
            '==========\n'])
end
%% Rotation Matrix
% Good Looking / Up Right
yaw = deg2rad(0);  % rotation around Z axis
pitch = deg2rad(0);  % rotation around Y axis
roll = deg2rad(-90); % rotation around X axis

% Normal
% yaw = deg2rad(0);  % rotation around Z axis
% pitch = deg2rad(0);  % rotation around Y axis
% roll = deg2rad(0); % rotation around X axis

Rz = [cos(yaw), -sin(yaw), 0;
      sin(yaw),  cos(yaw), 0;
      0,         0,        1];
Ry = [cos(pitch), 0, sin(pitch);
      0,          1, 0;
      -sin(pitch), 0, cos(pitch)];
Rx = [1, 0,         0;
      0, cos(roll), -sin(roll);
      0, sin(roll), cos(roll)];
Rotation_Matrix = Rz * Ry * Rx;

%% Merge and Export to STL
% Merge all faces (using global vertices)
merged_faces = bottom_faces;
if round_cond == true
    merged_faces = [merged_faces; arc_faces];
end
merged_faces = [merged_faces; top_faces; back_faces];
merged_vertices = vertices;

% Apply rotation
merged_vertices_rot = (Rotation_Matrix * merged_vertices')';

% Check for mesh closure
TR = triangulation(merged_faces, merged_vertices_rot);
free_edges = freeBoundary(TR);
if ~isempty(free_edges)
    disp('Mesh has boundary edges (holes detected).');
    disp(['Number of free edges: ' num2str(size(free_edges,1))]);
else
    disp('Mesh is closed (no holes).');
end

% Visualize merged mesh
if check_final_mesh_viz == true
    figure;
    trisurf(merged_faces, merged_vertices_rot(:,1), merged_vertices_rot(:,2), merged_vertices_rot(:,3), ...
        'FaceColor', 'cyan', 'EdgeColor', 'k', 'FaceAlpha', 1)
    axis equal
    xlabel('X (m)'); ylabel('Y (m)'); zlabel('Z (m)')
    title('Waverider Mesh')
    camlight headlight;
    lighting gouraud;
end

%% Export to STL
tri_obj = triangulation(merged_faces, merged_vertices_rot);
stlwrite(tri_obj, filepath, 'text');