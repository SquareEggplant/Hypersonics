%% STL Surface Area Calculator
% BY ERIC JO
%% Load STL file
clear; clc; close all;

addpath('C:/Users/erice/Documents/Hypersonic Club/Matlab Scripts/Analytical Hypersonic Trajectory Calculator/Functions/')
filename = 'C:/Users/erice/Documents/Hypersonic Club/Waverider Designs/M8_10deg_V10_highres_binary_round.stl';

panels = load_stl_mesh(filename);

%% Calculate Surface Area
area_m_sq = sum(panels.area);
area_cm_sq = area_m_sq * 100^2;

fprintf(['============\n' ...
    'The surface area of the STL: %g m^2 (%g cm^2)\n' ...
    '============\n\n'], area_m_sq, area_cm_sq);
%% Calculate Planform Area
% Input the constants of the LEP of the waverider
C1 = 0.5; C2 = 100; C3 = 1; C4 = 1; C5 = 1;
seed_num = 50;

x_LEP_prescaled = linspace(-0.05, 0.05, seed_num);
z_LEP_prescaled = C5*x_LEP_prescaled.^8 + C4*x_LEP_prescaled.^6 + C3*x_LEP_prescaled.^4 + C2*x_LEP_prescaled.^2 + C1;


% Calculate the Planform Area
Box_area = 0.1*max(z_LEP_prescaled);    % Area of the box
a_area = ((1/9)*C5*(0.05^9) + (1/7)*C4*(0.05^7) + (1/5)*C3*(0.05^5) + (1/3)*C2*(0.05^3) + C1*0.05);
b_area = ((1/9)*C5*((-0.05)^9) + (1/7)*C4*((-0.05)^7) + (1/5)*C3*((-0.05)^5) + (1/3)*C2*((-0.05)^3) + C1*(-0.05));
Curve_area = a_area - b_area;           % Area under the LEP
Planform_Area = Box_area - Curve_area;  % Planform Area (m^2)
Planform_Area_cm = Planform_Area * 100^2;
fprintf(['=======\n' ...
    'LEP SET\n' ...
    '=======\n\n'])
fprintf(['=======\n' ...
    'Planform Area of the Waverider: %g m^2 (%g cm^2)\n' ...
    '=======\n\n'], Planform_Area, Planform_Area_cm)
%% Calculate Volume enclosed by STL surface
volume = 0;
faces = panels.f;
vertices = panels.v;

for i = 1:size(faces,1)
    v1 = vertices(faces(i,1), :);
    v2 = vertices(faces(i,2), :);
    v3 = vertices(faces(i,3), :);
    
    % Signed volume of tetrahedron formed with origin
    tetra_vol = dot(v1, cross(v2, v3)) / 6;
    volume = volume + tetra_vol;
end

volume_m3 = abs(volume); % Ensure positive volume
volume_cm3 = volume_m3 * 1e6;

fprintf(['============\n' ...
    'Volume: %.6f m^3 (%.2f cm^3)\n' ...
    '============\n\n'], volume_m3, volume_cm3);

%% Volume Efficiency
threshold = 0.12;
h = (volume_m3^(2/3)) / area_m_sq;
fprintf(['============\n' ...
    'Volume Efficiency: %g' ...
    '\n============\n\n'], h);
if h >= threshold
    fprintf('The volume efficiency is acceptable :)\n');
else
    fprintf('The volume efficiency is below the acceptable threshold :(\n');
end