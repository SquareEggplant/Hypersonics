%% Chebyshev Polynomial Generator 
% BY ERIC JO
clear; clc; close all;

n = [1 2 3 4 5];
theta = linspace(0, 2*pi, 1000);
T = [];

figure; hold on;
for i = 1:length(n)
    Tn = cos(n(i)*theta) ./ cos(theta);
    plot(theta/max(theta), Tn/max(Tn))
    % T = [T; Tn];
end
xlabel('theta (rad)')
ylabel('y-axis')
title('Chebyshev Polynomials')
grid on; hold off;